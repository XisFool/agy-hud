import fs from 'fs';
import path from 'path';
import { getSessionState } from './parser.js';
import { renderHUD } from './renderer.js';
import { loadConfig } from './config.js';
import { getGitInfo } from './git.js';

const BASE_DIR = '/Users/c/.gemini/antigravity-cli';
const BRAIN_DIR = path.join(BASE_DIR, 'brain');
const PROJECT_DIR = '/Users/c/agy-hud';

function getLatestConversationId() {
  try {
    const dirs = fs.readdirSync(BRAIN_DIR)
      .filter(d => fs.statSync(path.join(BRAIN_DIR, d)).isDirectory() && d !== 'scratch')
      .sort((a, b) => fs.statSync(path.join(BRAIN_DIR, b)).mtimeMs - fs.statSync(path.join(BRAIN_DIR, a)).mtimeMs);
    return dirs[0];
  } catch (e) {
    return null;
  }
}

async function main() {
  const config = loadConfig(PROJECT_DIR);
  const isUpdate = process.argv.includes('--update');
  const convId = process.env.ANTIGRAVITY_CONVERSATION_ID || '074fc1f4-cbbf-47f5-b9d9-cd552ec1a2fd';
  const cacheFile = path.join(PROJECT_DIR, 'state.json');

  if (!convId) {
    if (!isUpdate) console.log('\x1b[1mAGY\x1b[0m | \x1b[90mIDLE\x1b[0m');
    return;
  }

  const logFile = path.join(BRAIN_DIR, convId, '.system_generated/logs/transcript.jsonl');
  if (!fs.existsSync(logFile)) {
    if (!isUpdate) console.log('AGY | READY');
    return;
  }

  try {
    // Optimization: only read last 5KB for update
    const content = fs.readFileSync(logFile, 'utf8');
    const lines = content.split('\n').filter(Boolean);
    const state = getSessionState(lines, logFile);
    state.gitInfo = getGitInfo();
    const lang = process.env.LANG?.startsWith('zh') ? 'zh' : 'en';
    const output = renderHUD(state, config, lang);

    if (isUpdate) {
      fs.writeFileSync(cacheFile, output);
    } else {
      // If we have a cache and it's fresh, use it. Otherwise, render now.
      if (fs.existsSync(cacheFile)) {
        console.log(fs.readFileSync(cacheFile, 'utf8'));
      } else {
        console.log(output);
      }
    }
  } catch (e) {
    if (!isUpdate) console.log('AGY | ERROR');
  }
}

main();
